# INVARIANTS, NOTES

# A. NB: harbor (a temporrary table) will not be visible via the SHOW TABLES statement

# B. DML Statements run ASYNC in MySQL.

# C. DML-Repeatedly invoke the next two statements to synthesize a dataset)
#     SELECT NOW();
#     SELECT UNIX_TIMESTAMP();

# D. SCAFFOLD | A one-time paste into a MySQL Terminal.




# START OF SCAFFOLD PASTE

DROP DATABASE IF EXISTS any;
CREATE DATABASE any; USE any;


DROP TABLE IF EXISTS events;
CREATE TABLE events (
    ID int,
    LName varchar(255),
    FName varchar(255),
    Property varchar(255),
    Instant long
);


DROP TABLE IF EXISTS harbor;
CREATE TEMPORARY TABLE harbor (id INT,FName varchar(255),LName varchar(255));


# SPROC-DISCERN | Detects events within predefined bounds
DROP PROCEDURE IF EXISTS discern;

DELIMITER //
CREATE PROCEDURE discern(IN start long, IN end long)
BEGIN

  DROP TABLE IF EXISTS harbor;
  CREATE TEMPORARY TABLE harbor (id INT,FName varchar(255),LName varchar(255));
  DESCRIBE harbor;

  DELETE FROM harbor;
  INSERT INTO harbor(id,FName,LName) SELECT ID, FName, LName FROM events WHERE Instant BETWEEN start and end;

  SELECT id,FName,LName INTO OUTFILE '/Users/greg/stage/AppMapReduceMySQLExtractFile/src/main/resources/events.txt'
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' FROM harbor;

END //
DELIMITER ;


# FINISH OF SCAFFOLD PASTE



# SPROC-DATASET: Populates test data (refreshes to known/sane state)
DROP PROCEDURE IF EXISTS dataset;

DELIMITER //
CREATE PROCEDURE dataset()
BEGIN

  DELETE FROM events;

  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196642);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196643);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196644);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196645);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196646);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196647);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196648);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196649);

  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196650);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196651);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196652);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196653);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196654);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196661);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196662);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196663);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196664);

  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196670);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196671);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196672);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196673);

END //
DELIMITER ;


# ¡IMPORTANTE!
call dataset;
SELECT * FROM events;

# Optional
# DELETE FROM events;


call discern(1660196650, 1660196664);
SELECT * FROM harbor;
