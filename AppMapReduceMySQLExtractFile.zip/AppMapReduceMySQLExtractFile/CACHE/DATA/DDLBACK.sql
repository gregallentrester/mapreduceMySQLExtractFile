


# DDL-A
DROP DATABASE IF EXISTS any;
CREATE DATABASE any; USE any;



# DDL-B
DROP TABLE IF EXISTS events;
CREATE TABLE events (
    ID int,
    LName varchar(255),
    FName varchar(255),
    Property varchar(255),
    Instant long
);
DESCRIBE events;



# DDL-C
DROP TABLE IF EXISTS harbor;
CREATE TEMPORARY TABLE harbor (id INT,FName varchar(255),LName varchar(255));
DESCRIBE harbor;





# SPROC1-DATASET: Populates test data (refreshs to known/sane state)
DROP PROCEDURE IF EXISTS dataset;
DELIMITER //
CREATE PROCEDURE dataset()
BEGIN

  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196642);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196643);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196644);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196645);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196646);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196647);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196648);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196649);

  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196650);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196651);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196652);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196653);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196654);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196661);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196662);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196663);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196664);

  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196670);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (9, "nine", "nine", "LV", 1660196671);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196672);
  INSERT INTO events (ID,LName,FName,Property,Instant)
  VALUES (10, "ten","ten","AC",1660196673);

END //
DELIMITER ;



# ¡IMPORTANTE!
call dataset;

# VERIFY
SELECT * FROM events;



# SPROC-DISCERN: Detects events/transactions within predefined time bounds
DROP PROCEDURE IF EXISTS discern;
DELIMITER //
CREATE PROCEDURE discern(IN start long, IN end long)
BEGIN
	SELECT ID FROM events WHERE Instant BETWEEN start and end;
END //
DELIMITER ;

# OR, Do math, internally, to determine the range (supply just the 'start/inception' value)
call discern(1660196649, 1660196670);


#  ¡Finalmente!
INSERT INTO harbor(id,FName,LName) SELECT ID, FName, LName FROM events WHERE Instant BETWEEN 1660196650 and 1660196664;



describe harbor;
SELECT id,FName,LName from harbor;


SELECT id,FName,LName INTO OUTFILE '/Users/greg/stage/AppMapReduceMySQLExtractFile/src/main/resources/events.txt'
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' FROM harbor;
